import os
import logging
from flask import Flask, request, jsonify  # type: ignore
from wakeonlan import send_magic_packet
 
logging.basicConfig(level=logging.INFO)
app = Flask(__name__)

# Función para detectar el broadcast dinámico
def obtener_broadcast():
    broadcast_env = os.getenv("BROADCAST_IP")
    if broadcast_env:
        logging.info(f"Usando BROADCAST_IP definido en entorno: {broadcast_env}")
        return broadcast_env
    default_broadcast = "255.255.255.255"
    logging.info(f"No se encontró BROADCAST_IP en el entorno, usando valor por defecto: {default_broadcast}")
    return default_broadcast
ip_broadcast = obtener_broadcast()
 
# Función para el envío del paquete mágico usando wakeonlan
def enviar_paquete_magico(mac, puerto=40000):
    try:
        for _ in range(5):
            send_magic_packet(mac, ip_address=ip_broadcast, port=puerto)
        msg = f"Paquete mágico enviado a {mac}"
        logging.info(msg + f" via {ip_broadcast}:{puerto}")
        return {"message": msg}
    except Exception as e:
        err = f"Error enviando paquete mágico a {mac}: {e}"
        logging.error(err)
        return {"message": err}
 
# Endpoint
@app.route('/wake', methods=['POST'])
def wake():
    data = request.get_json()
    if not data or "macs" not in data:
        return jsonify({"message": "JSON debe contener la clave 'macs'"}), 400
    macs = data["macs"]
    if isinstance(macs, str):
        macs = [macs]
    results = [enviar_paquete_magico(mac) for mac in macs]
    return jsonify(results)
# Arranque
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=4000, debug=False)