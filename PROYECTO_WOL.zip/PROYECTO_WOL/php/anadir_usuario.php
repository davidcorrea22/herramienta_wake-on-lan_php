<?php
session_start();
require "conexion.php";
require "funciones.inc.php";

# Si el usuario no es administrador, se le envía a index.php
if (!isset($_SESSION["login"]) || !isset($_SESSION["admin"])) {
    header("Location: index.php");
    exit();
}

$mensaje = "";
if (isset($_POST["anadir2"]) && $_SERVER["REQUEST_METHOD"] === "POST") {
    if (!empty($_POST["usuario"]) && !empty($_POST["con1"]) && !empty($_POST["con2"]) && !empty($_POST["rol"])) {
        $usr = limpiar($_POST["usuario"]);
        $con1 = limpiar($_POST["con1"]);
        $con2 = limpiar($_POST["con2"]);
        $rol = $_POST["rol"] == "admin" || $_POST["rol"] == "usuario" ? limpiar($_POST["rol"]) : "usuario";
        if ($con1 === $con2) {
            $contra = sha1($con1);
            if (validar_contra($con1) && validar_nombre($usr)) {
                try {
                    $consulta = "INSERT INTO usuarios (usuario, contrasena, rol) VALUES (?, ?, ?)";
                    error_log("Intentando agregar usuario: Nombre=$usr, Rol=$rol");
                    $sentencia = $conexion->prepare($consulta);
                    if (!$sentencia) {
                        throw new Exception($conexion->error);
                        error_log("Error preparando la consulta: $conexion->error");
                    }
                    if (!$sentencia->bind_param("sss", $usr, $contra, $rol)) {
                        throw new Exception($conexion->error);
                        error_log("Error vinculando la consulta: $conexion->error");
                    }
                    if (!$sentencia->execute()) {
                        throw new Exception($conexion->error);
                        error_log("Error ejecutando la consulta: $conexion->error");
                    }
                    $mensaje = "Se ha agregado el usuario correctamente.";
                    error_log("Usuario agregado: Nombre=$usr, Rol=$rol");
                    $sentencia->close();
                } catch (Exception $exc) {
                    $mensaje = "Se ha producido un error. Comprueba si el usuario ya existe.";
                    error_log("Error al insertar los datos: " . $exc->getMessage());
                }
            } else {
                $mensaje = "Error al verificar el formato de los parámetros.";
            }
        } else {
            $mensaje = "Las contraseñas no coinciden.";
        }
    } else {
        $mensaje = "Faltan datos oblitarios.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="David Correa Carmona">
    <link href="./estilos.css" rel="stylesheet" type="text/css">
    <title>Añadir Usuarios</title>
</head>

<body>
    <header>
        <h1>Añadir Usuarios</h1>
        <nav class="menu">
            <form action="./panel_equipos.php" method="post"><button type="submit" name="inicio">Volver A Inicio</button></form>
            <form action="./cuenta_usuario.php" method="post"><button type="submit" name="cuenta">Editar Cuenta</button></form>
            <form action="./index.php" method="post"><button type="submit" name="cerrar_sesion">Cerrar Sesión</button></form>
            <form action="./anadir_usuario.php" method="post"><button type="submit" name="usr_anadir">Añadir Usuarios</button></form>
            <form action="./borrar_usuario.php" method="post"><button type="submit" name="usr_borrar">Borrar Usuarios</button></form>
            <form action="./panel_usuario.php" method="post"><button type="submit" name="usuarios">Menú de usuarios</button></form>
        </nav>
    </header>
    <main>
        <p><?= $mensaje; ?></p>
        <form action="" method="post" class="formulario">
            <p>* Nombre de Usuario. Solo se permiten letras y números. Entre 3 y 50 carácteres: <input type="text" name="usuario" pattern="[a-zA-Z0-9_ ]{3,50}" required></p>
            <p>* Contraseña. Al menos 8 carácteres, un número, una mayúscula, una minúscula y un carácter especial: <input type="password" name="con1" pattern="(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[!@#$%^&*]).{8,}" required> </p>
            <p>* Repita La Contraseña: <input type="password" name="con2" pattern="(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[!@#$%^&*]).{8,}" required> </p>
            <p>* Rol del Usuario:
                <select name="rol" id="rol" required>
                    <option value="usuario">Usuario Estándar</option>
                    <option value="admin">Administrador</option>
                </select>
            </p>
            <p><input type="submit" name="anadir2" value="Añadir Cuenta"></p>
        </form>
    </main>
</body>

</html>