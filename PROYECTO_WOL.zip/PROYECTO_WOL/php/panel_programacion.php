<?php
session_start();
require "conexion.php";
require "funciones.inc.php";
date_default_timezone_set("Europe/Madrid");

if (!isset($_SESSION["login"])) {
    header("Location: index.php");
    exit();
}

$id = 1;
$mensaje = "";

if (isset($_POST["guardar"]) && $_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST["dias"]) && isset($_POST["hora"])) {
        $dias = implode(",", $_POST["dias"]);
        $hora = $_POST["hora"];

        $consulta = "REPLACE INTO programacion (id, dias, hora) VALUES (?, ?, ?)";
        if ($sentencia = $conexion->prepare($consulta)) {
            $sentencia->bind_param("iss", $id, $dias, $hora);
            if ($sentencia->execute()) {
                $mensaje = "Programacion guardada correctamente.";
                error_log("Se ha editado la programacion correctamente");
            } else {
                $mensaje = "Se ha producido un error guardando la programacion.";
                error_log("Se ha producido un error editando la programacion: $conexion->error");
            }
            $sentencia->close();
        }
    } else {
        $mensaje = "Faltan datos necesarios.";
    }
} elseif (isset($_POST["eliminar"]) && $_SERVER["REQUEST_METHOD"] == "POST") {
    $consulta = "DELETE FROM programacion WHERE id= ?";
    if ($sentencia = $conexion->prepare($consulta)) {
        $sentencia->bind_param("i", $id);
        if ($sentencia->execute()) {
            $mensaje = "Programación eliminada.";
            error_log("Se ha borrado la programación correctamente");
        } else {
            $mensaje = "Se ha producido un error eliminando la programacion.";
            error_log("Se ha producido un error borrar la programacion: $conexion->error");
        }
        $sentencia->close();
    }
}

$diasProg = [];
$horaProg = "";

$consulta2 = "SELECT * FROM programacion WHERE id=1";
$resultado = $conexion->query($consulta2);
if ($resultado->num_rows > 0) {
    $fila = $resultado->fetch_assoc();
    $diasProg = explode(",", $fila["dias"]);
    $horaProg = limpiar($fila["hora"]);
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="David Correa Carmona">
    <link href="./estilos.css" rel="stylesheet" type="text/css">
    <title>Programar Encendido</title>
</head>

<body>
    <header>
        <h1>Programar Encendido</h1>
        <nav class="menu">
            <form action="./panel_equipos.php" method="post"><button type="submit" name="inicio">Volver A Inicio</button></form>
            <form action="./solicitudes_wol.php" method="post"><button type="submit" name="encender_todos">Encender Todos</button></form>
            <form action="./panel_programacion.php" method="post"><button type="submit" name="programar">Programar Encendido</button></form>
            <form action="./cuenta_usuario.php" method="post"><button type="submit" name="cuenta">Editar Cuenta</button></form>
            <form action="./index.php" method="post"><button type="submit" name="cerrar_sesion">Cerrar Sesión</button></form>
            <?php
            if (isset($_SESSION["admin"])) {
                echo "<form action='./anadir_equipo.php' method='post'><button type='submit' name='anadir'>Añadir Equipos</button></form>";
                echo "<form action='./borrar_equipo.php' method='post'><button type='submit' name='borrar'>Borrar Equipos</button></form>";
                echo "<form action='./panel_usuario.php' method='post'><button type='submit' name='usuarios'>Menú De Usuarios</button></form>";
            }
            ?>
        </nav>
    </header>
    <main>
        <p><?= $mensaje ?></p>
        <form action="./panel_programacion.php" method="post" class="formulario">
            <fieldset>
                <legend>Selecciona los días de la semana</legend>
                <?php
                $trad = array("Lunes" => "Monday", "Martes" => "Tuesday", "Miércoles" => "Wednesday", "Jueves" => "Thursday", "Viernes" => "Friday", "Sábado" => "Saturday", "Domingo" => "Sunday");
                foreach ($trad as $esp => $ing) {
                    $checked = "";
                    if (in_array($ing, $diasProg)) {
                        $checked = "checked";
                    }
                    echo "<p>$esp <input type='checkbox' name='dias[]' value='$ing' $checked></p>";
                }
                ?>
            </fieldset>
            <fieldset>
                <legend>Selecciona la hora (Formato 24h)</legend>
                <p><input type="time" name="hora" value="<?= limpiar($horaProg) ?>" required></p>
            </fieldset>
            <input type="submit" name="guardar" value="Guardar Programación">
        </form>
        <form action="./panel_programacion.php" method="post" class="formulario">
            <input type="submit" name="eliminar" value="Eliminar Programación">
        </form>
    </main>
</body>

</html>