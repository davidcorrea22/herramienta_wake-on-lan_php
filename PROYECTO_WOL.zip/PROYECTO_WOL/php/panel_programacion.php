<?php
session_start();
require "conexion.php";
require "funciones.inc.php";
date_default_timezone_set("Europe/Madrid");

# Si el usuario no es administrador, se le envía a index.php
if (!isset($_SESSION["login"]) || !isset($_SESSION["admin"])) {
    header("Location: index.php");
    exit();
}

$mensaje = "";
$diasProg = [];
$horaProg = "";
$es_edicion = false;
$dispositivo_id = null;

if (isset($_GET["id"])) {
    $prog_id = intval($_GET["id"]);
    $consulta = "SELECT dispositivo_id, dias, hora FROM programacion WHERE id = ?";
    if ($sentencia = $conexion->prepare($consulta)) {
        $sentencia->bind_param("i", $prog_id);
        $sentencia->execute();
        $resultado = $sentencia->get_result();
        if ($resultado->num_rows > 0) {
            $fila = $resultado->fetch_assoc();
            $dispositivo_id = $fila["dispositivo_id"];
            $diasProg = explode(",", $fila["dias"]);
            $horaProg = $fila["hora"];
            $es_edicion = true;
        } else {
            $mensaje = "ID de programación inválido.";
        }
        $sentencia->close();
    }
} elseif (isset($_GET["disp"])) {
    $dispositivo_id = intval($_GET["disp"]);
    $consulta = "SELECT id FROM dispositivos WHERE id = ?";
    if ($sentencia = $conexion->prepare($consulta)) {
        $sentencia->bind_param("i", $dispositivo_id);
        $sentencia->execute();
        $resultado = $sentencia->get_result();
        if ($resultado->num_rows !== 1) {
            $mensaje = "ID de dispositivo inválido.";
            $dispositivo_id = null;
        }
        $sentencia->close();
    }
} else {
    $mensaje = "No se especificó ninguna programación ni dispositivo.";
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && $dispositivo_id) {
    if (isset($_POST["guardar"])) {
        if (!empty($_POST["dias"]) && !empty($_POST["hora"])) {
            $dias = implode(",", $_POST["dias"]);
            $hora = $_POST["hora"];
            $dispId = $dispositivo_id;

            $consulta = "INSERT INTO programacion (dispositivo_id, dias, hora) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE dias = VALUES(dias), hora = VALUES(hora)";
            if ($sentencia = $conexion->prepare($consulta)) {
                $sentencia->bind_param("iss", $dispId, $dias, $hora);
                if ($sentencia->execute()) {
                    $mensaje = $es_edicion ? "Programación actualizada correctamente." : "Programación creada correctamente.";
                    error_log("Se ha editado la programación correctamente");
                } else {
                    $mensaje = "Error al guardar la programación.";
                    error_log("Error al editar la programación: $conexion->error");
                }
                $sentencia->close();
            }

            header("Location: " . ($es_edicion ? "panel_programacion.php?id={$prog_id}" : "panel_programacion.php?disp={$dispositivo_id}"));
            exit();
        } else {
            $mensaje = "Faltan datos necesarios.";
        }
    } elseif (isset($_POST["eliminar"]) && $es_edicion) {
        $consulta = "DELETE FROM programacion WHERE id = ?";
        if ($sentencia = $conexion->prepare($consulta)) {
            $sentencia->bind_param("i", $prog_id);
            if ($sentencia->execute()) {
                $mensaje = "Programación eliminada.";
                $diasProg = [];
                $horaProg = "";
                $es_edicion = false;
                error_log("Se ha borrado la programación correctamente");
            } else {
                $mensaje = "Error al eliminar la programación.";
                error_log("Error al borrar la programación: $conexion->error");
            }
            $sentencia->close();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <meta name="author" content="David Correa Carmona">
    <link href="./estilos.css" rel="stylesheet" type="text/css">
    <title>Programar Encendido</title>
</head>
<body>
<header>
    <h1>Programar Encendido</h1>
    <nav class="menu">
        <form action="./panel_equipos.php" method="post"><button type="submit" name="inicio">Volver A Inicio</button></form>
        <form action="./solicitudes_wol.php" method="post"><button type="submit" name="encender_todos">Encender Todos</button></form>
        <form action="./cuenta_usuario.php" method="post"><button type="submit" name="cuenta">Editar Cuenta</button></form>
        <form action="./index.php" method="post"><button type="submit" name="cerrar_sesion">Cerrar Sesión</button></form>
        <?php
        if (isset($_SESSION["admin"])) {
            echo "<form action='./anadir_equipo.php' method='post'><button type='submit' name='anadir'>Añadir Equipos</button></form>";
            echo "<form action='./borrar_equipo.php' method='post'><button type='submit' name='borrar'>Borrar Equipos</button></form>";
            echo "<form action='./panel_usuario.php' method='post'><button type='submit' name='usuarios'>Menú De Usuarios</button></form>";
        }
        ?>
    </nav>
</header>
<main>
    <p><?= $mensaje ?></p>
    <?php if ($dispositivo_id): ?>
        <form action="<?= $es_edicion ? "panel_programacion.php?id={$prog_id}" : "panel_programacion.php?disp={$dispositivo_id}" ?>" method="post" class="formulario">
            <fieldset>
                <legend>Selecciona los días de la semana</legend>
                <?php
                $trad = array("Lunes" => "Monday", "Martes" => "Tuesday", "Miércoles" => "Wednesday", "Jueves" => "Thursday", "Viernes" => "Friday", "Sábado" => "Saturday", "Domingo" => "Sunday");
                foreach ($trad as $esp => $ing) {
                    $checked = in_array($ing, $diasProg) ? "checked" : "";
                    echo "<p><input type='checkbox' name='dias[]' value='$ing' $checked> $esp</p>";
                }
                ?>
            </fieldset>
            <fieldset>
                <legend>Selecciona la hora (Formato 24h)</legend>
                <p><input type="time" name="hora" value="<?= limpiar($horaProg) ?>" required></p>
            </fieldset>
            <input type="submit" name="guardar" value="<?= $es_edicion ? "Guardar Cambios" : "Crear Programación" ?>">
        </form>

        <?php if ($es_edicion): ?>
            <form action="panel_programacion.php?id=<?= $prog_id ?>" method="post" class="formulario">
                <input type="submit" name="eliminar" value="Eliminar Programación">
            </form>
        <?php endif; ?>
    <?php endif; ?>
</main>
</body>
</html>
