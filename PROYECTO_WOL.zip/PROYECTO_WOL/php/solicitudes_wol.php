<?php
session_start();
require "conexion.php";
require "funciones.inc.php";

if (!isset($_SESSION["login"])) {
    header("Location: index.php");
}

$fallos = 0;
$mensaje = "";
$res = [];
$link = "http://wol:4000/wake";

if (isset($_POST["encender_todos"]) && $_SERVER["REQUEST_METHOD"] == "POST") {
    $consulta = "SELECT mac FROM dispositivos";
    $resultado = $conexion->query($consulta);
    $macs = [];
    if ($resultado->num_rows > 0) {
        while ($fila = $resultado->fetch_assoc()) {
            if (validar_mac($fila["mac"])) {
                $macs[] = $fila["mac"];
            } else {
                $fallos = $fallos + 1;
            }
        }
        $mensaje = "$fallos / $resultado->num_rows paquetes han fallado";
        $res = peticion($link, $macs);
    } else {
        $mensaje = "No se han encontrado direcciones MAC válidas.";
    }
} elseif (isset($_POST["encender"]) && isset($_POST["mac"]) && $_SERVER["REQUEST_METHOD"] == "POST") {
    if (validar_mac($_POST["mac"])) {
        $res = peticion($link, $_POST["mac"]);
    } else {
        $mensaje = "La dirección MAC no es válida.";
    }
}

?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="David Correa Carmona">
    <link href="./estilos.css" rel="stylesheet" type="text/css">
    <title>Página Intermedia</title>
</head>

<body>
    <header>
        <h1>Página Intermedia</h1>
        <nav class="menu">
            <form action="./panel_equipos.php" method="post"><button type="submit" name="inicio">Volver A Inicio</button></form>
            <form action="./solicitudes_wol.php" method="post"><button type="submit" name="encender_todos">Encender Todos</button></form>
            <form action="./panel_programacion.php" method="post"><button type="submit" name="programar">Programar Encendido</button></form>
            <form action="./cuenta_usuario.php" method="post"><button type="submit" name="cuenta">Editar Cuenta</button></form>
            <form action="./index.php" method="post"><button type="submit" name="cerrar">Cerrar Sesión</button></form>
            <?php
            if (isset($_SESSION["admin"])) {
                echo "<form action='./anadir_equipo.php' method='post'><button type='submit' name='anadir'>Añadir Equipos</button></form>";
                echo "<form action='./borrar_equipo.php' method='post'><button type='submit' name='borrar'>Borrar Equipos</button></form>";
                echo "<form action='./panel_usuario.php' method='post'><button type='submit' name='usuarios'>Menú De Usuarios</button></form>";
            }
            ?>
        </nav>
    </header>
    <main>
        <p><?= $mensaje; ?></p>
        <table>
            <thead>
                <th>ESTADO DE LOS PAQUETES</th>
            </thead>
            <tbody>
                <?php foreach ($res as $resultado) { ?>
                    <tr>
                        <td><?= isset($resultado["message"]) ? limpiar($resultado["message"]) : "ERROR" ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </main>
</body>

</html>