<?php
# Creamos una función encargada de hacer peticiones a una url y recibir una respuesta.
# En primer lugar, creamos un array llamado opciones en el que especificamos las carácteristicas de la petición que vamos a hacer.
#   1) En el header, especificamos que el contenido de la solicitus se hará en JSON.
#   2) La solicitud será de tipo POST
#   3) El contenido, que será encodificado a JSON, será un array de direcciones MAC.
# @file_get_content:
#   1) El @ se usa para quitar los mensajes de error.
#   2) Envía la solicitus a la URL, sin INCLUDE_PATH y usando el contexto definido antes.
# Si la solicitud sale bien, se duevuelve el resultado decodificado.
function peticion($link, $macs)
{
    $opciones = [
        "http" => [
            "header" => "Content-Type: application/json",
            "method" => "POST",
            "content" => json_encode(["macs" => $macs]),
        ],
    ];
    $contexto = stream_context_create($opciones);
    $resultado = @file_get_contents($link, false, $contexto);
    if ($resultado === FALSE) {
        return [["error" => "Error al enviar la solicitud."]];
    } else {
        return json_decode($resultado, true);
    }
}

# Limpia los datos antes de mostrarlos por pantalla o insertarlos a la base de datos
function limpiar($dato)
{
    return htmlspecialchars(trim(strip_tags($dato)));
}

# Valida el formato de una dirección MAC
function validar_mac($mac) {
    return preg_match('/^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$/', $mac);
}

# Valida la complejidad de una contraseña
function validar_contra($contra) {
    return preg_match('/^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{8,}$/', $contra);
}

# Valida un nombre de usuario
function validar_nombre($nom) {
    return preg_match('/^[a-zA-Z0-9_ ]{3,50}$/', $nom);
}

# Valida el formato de una IP
function validar_ip($ip) {
    return preg_match('/^((25[0-5]|2[0-4][0-9]|[0-1]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[0-1]?[0-9][0-9]?)$/', $ip);
}

