<?php
$servidor = "db";
$usuario = "user";
$pass = "userpassword";
$db = "equipos";

# Bucle que intenta conectarse a la Base de Datos 10 veces, una cada 20 segundos.
$contador = 0;
$max_reintentos = 10;
while ($contador < $max_reintentos) {
    $conexion = @new mysqli($servidor, $usuario, $pass, $db);
    if (!$conexion->connect_errno) {
        break;
    } else {
        $contador++;
        if ($contador >= $max_reintentos) {
            die("No se pudo conectar a MySQL después de varios intentos.");
        }
        sleep(20);
    }
}

# Crea las tablas en caso de que no existan.
$dispositivos = "CREATE TABLE IF NOT EXISTS dispositivos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    mac CHAR(17) NOT NULL UNIQUE,
    descripcion VARCHAR(300) DEFAULT NULL,
    ip VARCHAR(15) NOT NULL UNIQUE
)";
$conexion->query($dispositivos);

$programacion = "CREATE TABLE IF NOT EXISTS programacion (
    id INT AUTO_INCREMENT PRIMARY KEY,
    dispositivo_id INT NOT NULL,
    dias VARCHAR(56) NOT NULL,
    hora TIME NOT NULL,
    UNIQUE KEY ux_prog_dispositivo (dispositivo_id),
    CONSTRAINT fk_prog_disp
      FOREIGN KEY (dispositivo_id)
      REFERENCES dispositivos(id)
      ON DELETE CASCADE
)";
$conexion->query($programacion);

$usuarios = "CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario VARCHAR(50) NOT NULL UNIQUE,
    contrasena VARCHAR(300) NOT NULL,
    rol ENUM('admin','usuario') NOT NULL DEFAULT 'usuario'
)";
$conexion->query($usuarios);

# Se crea un usuario por defecto
$admin = "SELECT COUNT(*) AS total FROM usuarios WHERE rol='admin'";
$resultado = $conexion->query($admin);
$fila = $resultado->fetch_assoc();
if ($fila["total"] == 0) {
    $nom = "administrador";
    $contra = sha1("administrador");
    $rol = "admin";
    try {
        $admin2 = "INSERT INTO usuarios (usuario, contrasena, rol) VALUES (?, ?, ?)";
        error_log("Intentando agregar el usuario por defecto.");
        $sentencia = $conexion->prepare($admin2);
        if (!$sentencia) {
            throw new Exception($conexion->error);
            error_log("Error preparando la consulta: $conexion->error");
        }
        if (!$sentencia->bind_param("sss", $nom, $contra, $rol)) {
            throw new Exception($conexion->error);
            error_log("Error vinculando la consulta: $conexion->error");
        }
        if (!$sentencia->execute()) {
            throw new Exception($conexion->error);
            error_log("Error ejecutando la consulta: $conexion->error");
        }
        error_log("Se ha agregado el usuario por defecto.");
        $sentencia->close();
    } catch (Exception $exc) {
        error_log("Error al insertar los datos: " . $exc->getMessage());
    }
    try {
        $contra = sha1("administrador");
        $admin3 = "UPDATE usuarios SET rol=? , contrasena=? WHERE usuario=?";
        error_log("Intentando configurar el usuario por defecto.");
        $sentencia = $conexion->prepare($admin3);
        if (!$sentencia) {
            throw new Exception($conexion->error);
            error_log("Error preparando la consulta: $conexion->error");
        }
        if (!$sentencia->bind_param("sss", $rol, $contra, $nom)) {
            throw new Exception($conexion->error);
            error_log("Error vinculando la consulta: $conexion->error");
        }
        if (!$sentencia->execute()) {
            throw new Exception($conexion->error);
            error_log("Error ejecutando la consulta: $conexion->error");
        }
        error_log("Se ha configurado el usuario por defecto.");
        $sentencia->close();
    } catch (Exception $exc) {
    }
}
