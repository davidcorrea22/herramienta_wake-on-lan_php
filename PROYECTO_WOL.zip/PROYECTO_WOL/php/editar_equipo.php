<?php
session_start();
require "conexion.php";
require "funciones.inc.php";

if (!isset($_SESSION["login"]) || !isset($_SESSION["admin"])) {
    header("Location: index.php");
    exit();
}

$mensaje = "";
if (isset($_GET["id"])) {
    $id = intval(limpiar($_GET["id"]));
    $consulta = "SELECT * FROM dispositivos WHERE id = $id";
    $resultado = $conexion->query($consulta);
    if ($resultado->num_rows > 0) {
        $fila = $resultado->fetch_assoc();
        $nom = limpiar($fila["nombre"]);
        $des = limpiar($fila["descripcion"]);
        $mac = limpiar($fila["mac"]);
        $ip = limpiar($fila["ip"]);
    } else {
        die("No se ha encontrado ningún equipo con la ID $id.");
    }
} else {
    die("No se ha especificado ninguna ID.");
}

if (isset($_POST["editar"])  && $_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST["id"]) && !empty($_POST["nombre"]) && !empty($_POST["mac"]) && !empty($_POST["ip"])) {
        $id = limpiar($_POST["id"]);
        $nom2 = limpiar($_POST["nombre"]);
        $mac2 = limpiar($_POST["mac"]);
        $des2 = isset($_POST["descripcion"]) ? limpiar($_POST["descripcion"]) : '';
        $ip2 = limpiar($_POST["ip"]);
        if (validar_mac($mac2) && validar_nombre($nom2) && validar_ip($ip2)) {
            try {
                $consulta = "UPDATE dispositivos SET nombre = ?, descripcion = ?, mac = ?, ip = ? WHERE id = ?";
                error_log("Intentando editar el equipo: Id=$id, Nombre=$nom, MAC=$mac, IP=$ip");
                $sentencia = $conexion->prepare($consulta);
                if (!$sentencia) {
                    error_log("Error preparando la consulta: $conexion->error");
                    throw new Exception($conexion->error);
                }
                if (!$sentencia->bind_param("ssssi", $nom2, $des2, $mac2, $ip2, $id)) {
                    error_log("Error vinculando la consulta: $conexion->error");
                    throw new Exception($conexion->error);
                }
                if (!$sentencia->execute()) {
                    error_log("Error ejecutando la consulta: $conexion->error");
                    throw new Exception($conexion->error);
                }
                $mensaje = "Se ha editado el equipo correctamente.";
                error_log("Equipo editado: Id=$id, Nombre=$nom2, MAC=$mac2, IP=$ip2");
                $sentencia->close();
            } catch (Exception $exc) {
                $mensaje = "Se ha producido un error. Puede que la MAC o la IP ya existan o la descripción haya superado el limite de caracteres.";
                error_log("Error al editar los datos: " . $exc->getMessage());
            }
        } else {
            $mensaje = "Error al verificar el formato de los parámetros.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="David Correa Carmona">
    <link href="./estilos.css" rel="stylesheet" type="text/css">
    <title>Editar equipo</title>
</head>

<body>
    <header>
        <h1>Editar el equipo</h1>
        <nav class="menu">
            <form action="./panel_equipos.php" method="post"><button type="submit" name="inicio">Volver A Inicio</button></form>
            <form action="./solicitudes_wol.php" method="post"><button type="submit" name="encender_todos">Encender Todos</button></form>
            <form action="./panel_programacion.php" method="post"><button type="submit" name="programar">Programar Encendido</button></form>
            <form action="./cuenta_usuario.php" method="post"><button type="submit" name="cuenta">Editar Cuenta</button></form>
            <form action="./index.php" method="post"><button type="submit" name="cerrar_sesion">Cerrar Sesión</button></form>
            <?php
            if (isset($_SESSION["admin"])) {
                echo "<form action='./anadir_equipo.php' method='post'><button type='submit' name='anadir'>Añadir Equipos</button></form>";
                echo "<form action='./borrar_equipo.php' method='post'><button type='submit' name='borrar'>Borrar Equipos</button></form>";
                echo "<form action='./panel_usuario.php' method='post'><button type='submit' name='usuarios'>Menú De Usuarios</button></form>";
            }
            ?>
        </nav>
    </header>
    <main>
        <p><?= $mensaje ?></p>
        <form action="" method="post" class="formulario">
            <input type="hidden" name="id" value="<?= $id ?>">
            <p>* Nombre del equipo. Solo letras y números. Mínimo 3 carácteres, máximo 50: <input type="text" name="nombre" value="<?= $nom ?>" pattern="[a-zA-Z0-9_ ]{3,50}" required></p>
            <p>* Dirección MAC. No puede coincidir con otra existente en la base de datos. Formato = XX:XX:XX:XX:XX:<input type="text" name="mac" value="<?= $mac ?>" pattern="^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$" required></p>
            <p>* Descripción. Este campo es opcional. Limite de 300 carácteres: <input type="text" name="descripcion" value="<?= $des ?>"></p>
            <p>* Dirección IP. No puede coincidir con otra existente en la base de datos: <input type="text" name="ip" value="<?= $ip ?>" pattern="^(25[0-5]|2[0-4][0-9]|[0-1]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[0-1]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[0-1]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[0-1]?[0-9][0-9]?)$" required></p>
            <p><input type="submit" name="editar" value="Editar"></p>
        </form>
    </main>
</body>

</html>