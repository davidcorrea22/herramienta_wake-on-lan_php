<?php
session_start();
require "conexion.php";
require "funciones.inc.php";

if (!isset($_SESSION["login"]) || !isset($_SESSION["admin"])) {
    header("Location: index.php");
    exit();
}

$mensaje = "";
if (isset($_POST["borrar2"]) && $_SERVER["REQUEST_METHOD"] == "POST" && is_array($_POST["borrar2"])) {
    $ids = array_filter($_POST["borrar2"], "is_numeric");
    if (!empty($ids)) {
        $lista_ids = implode(",", array_map("intval", $ids));
        if (in_array($_SESSION["id"], $ids)) {
            $mensaje = "No puedes eliminar tu propio usuario.";
        } else {
            try {
                $consulta = "DELETE FROM usuarios WHERE id IN ($lista_ids)";
                error_log("Intentando eliminar usuarios con IDS: $lista_ids");
                if ($conexion->query($consulta)) {
                    $mensaje = "Usuarios eliminados correctamente.";
                    error_log("Usuarios eliminados correctamente: $lista_ids");
                } else {
                    $mensaje = "Error al eliminar usuarios.";
                    error_log("Error al eliminar los usuarios: $conexion->error");
                }
            } catch (Exception $exc) {
                $mensaje = "Error inesperado.";
                error_log("Error inesperado: $conexion->error");
            }
        }
    } else {
        $mensaje = "No se ha seleccionado ningún usuario válido para borrar.";
    }
} else {
    $mensaje = "No se ha seleccionado ningún usuario para borrar.";
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="David Correa Carmona">
    <link href="./estilos.css" rel="stylesheet" type="text/css">
    <title>Borrar Usuarios</title>
</head>

<body>
    <header>
        <h1>Borrar Usuarios</h1>
        <nav class="menu">
            <form action="./panel_equipos.php" method="post"><button type="submit" name="inicio">Volver A Inicio</button></form>
            <form action="./cuenta_usuario.php" method="post"><button type="submit" name="cuenta">Editar Cuenta</button></form>
            <form action="./index.php" method="post"><button type="submit" name="cerrar_sesion">Cerrar Sesión</button></form>
            <form action="./anadir_usuario.php" method="post"><button type="submit" name="usr_anadir">Añadir Usuarios</button></form>
            <form action="./borrar_usuario.php" method="post"><button type="submit" name="usr_borrar">Borrar Usuarios</button></form>
            <form action="./panel_usuario.php" method="post"><button type="submit" name="usuarios">Menú de usuarios</button></form>
        </nav>
    </header>

    <main>
        <p><?= $mensaje ?></p>
        <form action="" method="post">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>USUARIO</th>
                        <th>ROL</th>
                        <th>SELECCIONAR</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $consulta2 = "SELECT * FROM usuarios";
                    $resultado2 = $conexion->query($consulta2);
                    while ($fila = $resultado2->fetch_assoc()) {
                        echo "<tr>
                            <td>" . intval($fila["id"]) . "</td>
                            <td>" . limpiar($fila["usuario"]) . "</td>
                            <td>" . limpiar($fila["rol"]) . "</td>
                            <td><input type='checkbox' name='borrar2[]' value='" . intval($fila["id"]) . "'></td>
                        </tr>";
                    }
                    ?>
                </tbody>
            </table>
            <p><input type="submit" name="borrado2" value="Borrar usuarios seleccionados"></p>
        </form>
        <?php $conexion->close(); ?>
    </main>
</body>

</html>