<?php
session_start();
require "conexion.php";
require "funciones.inc.php";

# Si el usuario no es administrador, se le envía a index.php
if (!isset($_SESSION["login"]) || !isset($_SESSION["admin"])) {
    header("Location: index.php");
    exit();
}

# "Borrar" debe ser un array enviado por POST con al menos una ID válida para procesar la solicitud
$mensaje = "";
if (isset($_POST["borrar"]) && $_SERVER["REQUEST_METHOD"] == "POST" && is_array($_POST["borrar"])) {
    $ids = array_filter($_POST["borrar"], "is_numeric");
    if (!empty($ids)) {
        $lista_ids = implode(",", array_map("intval", $ids));
        try {
            $consulta = "DELETE FROM dispositivos WHERE id IN ($lista_ids)";
            error_log("Intentando eliminar equipos con IDS: $lista_ids");
            if ($conexion->query($consulta)) {
                $mensaje = "Se han eliminado los equipos correctamente";
                error_log("Equipos eliminados con IDS: $lista_ids");
            } else {
                error_log("Error al eliminar los equipos: $conexion->error");
                throw new Exception($conexion->error);
            }
        } catch (Exception $exc) {
            $mensaje = "Error inesperado.";
            error_log("Error inesperado: $conexion->error");
        }
    } else {
        $mensaje = "No se ha seleccionado ningún equipo válido para borrar.";
    }
} else {
    $mensaje = "No se ha seleccionado ningún equipo para borrar.";
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="David Correa Carmona">
    <link href="./estilos.css" rel="stylesheet" type="text/css">
    <title>Borrar Equipos</title>
</head>

<body>
    <header>
        <h1>Borrar Equipos</h1>
        <nav class="menu">
            <form action="./panel_equipos.php" method="post"><button type="submit" name="inicio">Volver A Inicio</button></form>
            <form action="./solicitudes_wol.php" method="post"><button type="submit" name="encender_todos">Encender Todos</button></form>
            <form action="./panel_programacion.php" method="post"><button type="submit" name="programar">Programar Encendido</button></form>
            <form action="./cuenta_usuario.php" method="post"><button type="submit" name="cuenta">Editar Cuenta</button></form>
            <form action="./index.php" method="post"><button type="submit" name="cerrar_sesion">Cerrar Sesión</button></form>
            <?php
            if (isset($_SESSION["admin"])) {
                echo "<form action='./anadir_equipo.php' method='post'><button type='submit' name='anadir'>Añadir Equipos</button></form>";
                echo "<form action='./borrar_equipo.php' method='post'><button type='submit' name='borrar'>Borrar Equipos</button></form>";
                echo "<form action='./panel_usuario.php' method='post'><button type='submit' name='usuarios'>Menú De Usuarios</button></form>";
            }
            ?>
        </nav>
    </header>
    <main>
        <p><?= $mensaje ?></p>
        <form action="" method="post">
            <table>
                <thead>
                    <tr>
                        <th>DISPOSITIVO</th>
                        <th>DESCRIPCIÓN</th>
                        <th>MAC</th>
                        <th>IP</th>
                        <th>SELECCIONAR</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $consulta2 = "SELECT * FROM dispositivos";
                    $resultado2 = $conexion->query($consulta2);
                    while ($fila = $resultado2->fetch_assoc()) {
                        echo "<tr>
                            <td>" . limpiar($fila['nombre']) . "</td>
                            <td>" . limpiar($fila['descripcion']) . "</td>
                            <td>" . limpiar($fila['mac']) . "</td>
                            <td>" . limpiar($fila['ip']) . "</td>
                            <td><input type='checkbox' name='borrar[]' value='" . intval(limpiar($fila['id'])) . "'></td>
                        </tr>";
                    }
                    ?>
                </tbody>
            </table>
            <p><input type="submit" name="borrado" value="Borrar equipos seleccionados"></p>
        </form>
        <?php $conexion->close(); ?>
    </main>
</body>

</html>