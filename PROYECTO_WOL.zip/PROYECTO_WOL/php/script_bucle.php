<?php
set_time_limit(0);
date_default_timezone_set("Europe/Madrid");
require "conexion.php";
require "funciones.inc.php";

# Define una función para mandar una solicitud a solicitudes_wol.php para encender todos los equipos
function encender()
{
    $datos = http_build_query(["encender_todos" => "1"]);
    $opciones = [
        "http" => [
            "header" => "Content-Type: application/x-www-form-urlencoded\r\n",
            "method" => "POST",
            "content" => $datos,
        ],
    ];
    $contexto = stream_context_create($opciones);
    @file_get_contents("http://php/solicitudes_wol.php", false, $contexto);
}
# Cada 30 segundos, comprueba si hay conexión a la base de datos, si hay una programación activa y si dicha programación es ahora
while (true) {
    if (!$conexion) {
        sleep(30);
        continue;
    }
    $consulta = "SELECT * FROM programacion WHERE id=1";
    $resultado = $conexion->query($consulta);
    if ($resultado->num_rows > 0) {
        $fila = $resultado->fetch_assoc();
        $diasProg = explode(",", $fila["dias"]);
        $horaProg = limpiar($fila["hora"]);
        $dia = date("l");
        $hora = date("H:i:00");
        $diferencia = abs(strtotime($hora) - strtotime($horaProg));

        if (in_array($dia, $diasProg) && $diferencia < 60) {
            encender();
        }
    }
    sleep(30);
}
