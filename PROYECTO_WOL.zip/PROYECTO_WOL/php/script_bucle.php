<?php
set_time_limit(0);
date_default_timezone_set("Europe/Madrid");
require "conexion.php";
require "funciones.inc.php";

# Cada 30 segundos, comprueba si hay conexión a la base de datos, si hay una programación activa y si dicha programación es ahora
$link = "http://wol:4000/wake";
while (true) {
    if (!$conexion) {
        sleep(30);
        continue;
    }
    $dia = date("l");
    $consulta = "
        SELECT p.hora, d.mac
        FROM programacion p INNER JOIN dispositivos d ON p.dispositivo_id = d.id
        WHERE FIND_IN_SET(?, p.dias)
    ";
    $sentencia = $conexion->prepare($consulta);
    $sentencia->bind_param("s", $dia);
    $sentencia->execute();
    $resultado = $sentencia->get_result();
    if ($resultado && $resultado->num_rows > 0) {
        $hora = date("H:i:00");
        while ($fila = $resultado->fetch_assoc()) {
            $horaProg = limpiar($fila["hora"]);
            $diferencia = abs(strtotime($hora) - strtotime($horaProg));
            if ($diferencia < 60) {
                $mac = $fila["mac"];
                peticion($link, [$mac]);
            }
        }
    }
    $sentencia->close();
    sleep(30);
}
