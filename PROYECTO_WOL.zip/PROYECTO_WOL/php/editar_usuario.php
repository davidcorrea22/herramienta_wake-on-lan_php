<?php
session_start();
require "conexion.php";
require "funciones.inc.php";

# Si el usuario no es administrador, se le envía a index.php
if (!isset($_SESSION["login"]) || !isset($_SESSION["admin"])) {
    header("Location: index.php");
    exit();
}

$mensaje = "";
if (isset($_GET["id"])) {
    $id = intval(limpiar($_GET["id"]));
    $consulta = "SELECT * FROM usuarios WHERE id = $id";
    $resultado = $conexion->query($consulta);
    if ($resultado->num_rows > 0) {
        $fila = $resultado->fetch_assoc();
        $usr = limpiar($fila["usuario"]);
        $con = limpiar($fila["contrasena"]);
        $rol = limpiar($fila["rol"]);
    } else {
        die("No se ha encontrado ningún usuario con la ID $id.");
    }
} else {
    die("No se ha especificado ninguna ID.");
}

if (isset($_POST["editar2"]) && $_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST["nombre"]) && !empty($_POST["oldpasswd"]) && isset($_POST["rol"])) {
        $nom = limpiar($_POST["nombre"]);
        $ContraAntigua = sha1(limpiar($_POST["oldpasswd"]));
        $RolNuevo = in_array($_POST["rol"], ["admin", "usuario"]) ? $_POST["rol"] : "usuario";

        if (validar_nombre($nom) && $ContraAntigua == $con) {
            $ContraNueva = $ContraAntigua;
            if (!empty($_POST["newpasswd1"]) && !empty($_POST["newpasswd2"])) {
                $newpasswd1 = limpiar($_POST["newpasswd1"]);
                $newpasswd2 = limpiar($_POST["newpasswd2"]);
                if ($newpasswd1 === $newpasswd2) {
                    if (validar_contra($newpasswd1)) {
                        $ContraNueva = sha1($newpasswd1);
                        if ($ContraNueva ===  $con) {
                            $mensaje = "La nueva contraseña no puede ser la misma que la anterior.";
                        }
                    } else {
                        $mensaje = "La nueva contraseña no cumple los requisitos de seguridad.";
                    }
                } else {
                    $mensaje = "Las nuevas contraseñas no coinciden.";
                }
            }
            if (empty($mensaje)) {
                try {
                    $consulta = "UPDATE usuarios SET usuario = ?, contrasena = ?, rol = ? WHERE id = ?";
                    error_log("Intentando editar el usuario: Id=$id, Nombre=$usr, Rol=$rol");
                    $sentencia = $conexion->prepare($consulta);
                    if (!$sentencia) {
                        error_log("Error preparando la consulta: $conexion->error");
                        throw new Exception($conexion->error);
                    }
                    if (!$sentencia->bind_param("sssi", $nom, $ContraNueva, $RolNuevo, $id)) {
                        error_log("Error vinculando la consulta: $conexion->error");
                        throw new Exception($conexion->error);
                    }
                    if (!$sentencia->execute()) {
                        error_log("Error ejecutando la consulta: $conexion->error");
                        throw new Exception($conexion->error);
                    }
                    $mensaje = "Se ha editado el usuario correctamente.";
                    error_log("Usuario editado: Id=$id, Nombre=$nom, Rol=$RolNuevo");
                    $sentencia->close();
                } catch (Exception $exc) {
                    $mensaje = "Se ha producido un error.";
                    error_log("Error al editar los datos: " . $exc->getMessage());
                }
            }
        } else {
            $mensaje = "El nombre de usuario o la contraseña no son los correctos.";
        }
    } else {
        $mensaje = "Faltan datos obligatorios.";
    }
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="David Correa Carmona">
    <link href="./estilos.css" rel="stylesheet" type="text/css">
    <title>Modificar Cuenta</title>
</head>

<body>
    <header>
        <h1>Modificar Cuenta</h1>
        <nav class="menu">
            <form action="./panel_equipos.php" method="post"><button type="submit" name="inicio">Volver A Inicio</button></form>
            <form action="./cuenta_usuario.php" method="post"><button type="submit" name="cuenta">Editar Cuenta</button></form>
            <form action="./index.php" method="post"><button type="submit" name="cerrar_sesion">Cerrar Sesión</button></form>
            <form action="./anadir_usuario.php" method="post"><button type="submit" name="usr_anadir">Añadir Usuarios</button></form>
            <form action="./borrar_usuario.php" method="post"><button type="submit" name="usr_borrar">Borrar Usuarios</button></form>
            <form action="./panel_usuario.php" method="post"><button type="submit" name="usuarios">Menú de usuarios</button></form>
        </nav>
    </header>
    <main>
        <p><?= $mensaje ?></p>
        <form action="" method="post" class="formulario">
            <input type="hidden" name="id" value="<?= $id ?>">
            <p>* Nombre de usuario. Solo letras y números. Mínimo 3 carácteres, máximo 50:<input type="text" name="nombre" value="<?= limpiar($usr) ?>" pattern="[a-zA-Z0-9_ ]{3,50}" required></p>
            <p>* Contraseña Actual. La que usa ahora mismo. Al menos 8 carácteres, un número, una mayúscula, una minúscula y un carácter especial:<input type="password" name="oldpasswd" required></p>
            <p>* Nueva Contraseña. Opcional:<input type="password" name="newpasswd1" pattern="(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[!@#$%^&*]).{8,}"></p>
            <p>* Repita La Nueva Contraseña:<input type="password" name="newpasswd2" pattern="(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[!@#$%^&*]).{8,}"></p>
            <p>* Rol del Usuario:
                <select name="rol" id="rol" required>
                    <option value="usuario" <?= ($rol === "usuario") ? "selected" : "" ?>>Usuario Estándar</option>
                    <option value="admin" <?= ($rol === "admin") ? "selected" : "" ?>>Administrador</option>
                </select>
            </p>
            <p><input type="submit" name="editar2" value="Editar Cuenta"></p>
        </form>
    </main>
</body>

</html>