<?php
session_start();
require "conexion.php";
require "funciones.inc.php";

# Si el usuario no ha iniciado sesión, se le envía a index.php
if (!isset($_SESSION["login"])) {
    header("Location: index.php");
    exit();
}

$consulta = "SELECT 
    d.id AS disp_id,
    d.nombre AS disp_nombre,
    d.descripcion AS disp_desc,
    d.mac AS disp_mac,
    d.ip AS disp_ip,
    p.id AS prog_id,
    p.dias AS prog_dias,
    p.hora AS prog_hora
    FROM dispositivos d LEFT JOIN programacion p ON p.dispositivo_id = d.id
    ORDER BY d.id;
";
$resultado = $conexion->query($consulta);

# Se traduce la programación por medio de un array
$trad = array(
    "Monday" => "Lunes",
    "Tuesday" => "Martes",
    "Wednesday" => "Miércoles",
    "Thursday" => "Jueves",
    "Friday" => "Viernes",
    "Saturday" => "Sábado",
    "Sunday" => "Domingo"
);
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Panel de control</title>
    <link href="./estilos.css" rel="stylesheet">
</head>

<body>
    <header>
        <h1>Panel de control</h1>
        <nav class="menu">
            <form action="./panel_equipos.php" method="post"><button type="submit">Volver A Inicio</button></form>
            <form action="./solicitudes_wol.php" method="post"><button type="submit" name="encender_todos">Encender Todos</button></form>
            <form action="./cuenta_usuario.php" method="post"><button type="submit">Editar Cuenta</button></form>
            <form action="./index.php" method="post"><button type="submit" name="cerrar_sesion">Cerrar Sesión</button></form>
            <?php
            if (isset($_SESSION["admin"])) {
                echo "<form action='./anadir_equipo.php' method='post'><button type='submit' name='anadir'>Añadir Equipos</button></form>";
                echo "<form action='./borrar_equipo.php' method='post'><button type='submit' name='borrar'>Borrar Equipos</button></form>";
                echo "<form action='./panel_usuario.php' method='post'><button type='submit' name='usuarios'>Menú De Usuarios</button></form>";
            }
            ?>
        </nav>
    </header>
    <main>
        <table>
            <thead>
                <tr>
                    <th>DISPOSITIVO</th>
                    <th>DESCRIPCIÓN</th>
                    <?php
                    if (isset($_SESSION["admin"])) {
                        echo "<th>MAC</th>";
                        echo "<th>IP</th>";
                    }
                    ?>
                    <th>ESTADO</th>
                    <th>DÍAS</th>
                    <th>HORA</th>
                    <th
                        <?php if (isset($_SESSION["admin"])) {
                            echo "colspan='3'";
                        }
                        ?>>ACCIÓN
                    </th>
                </tr>
            </thead>
            <tbody>

                <?php
                # Se hace ping a cada IP almacenada en la base de datos para saber si está encendida o apagada y se traducen los días
                while ($fila = $resultado->fetch_assoc()) {
                    $estado = exec("ping -c 1 -W 1 " . escapeshellarg(limpiar($fila["disp_ip"])) . " > /dev/null 2>&1 && echo 'Encendido' || echo 'Apagado'");
                    $diasEspañol = "";
                    if ($fila["prog_dias"]) {
                        $dias = array_map('trim', explode(",", limpiar($fila["prog_dias"])));
                        $diasEspañol = array_map(function ($dia) use ($trad) {
                            return isset($trad[$dia]) ? $trad[$dia] : $dia;
                        }, $dias);
                        $diasEspañol = implode(', ', $diasEspañol);
                    }
                ?>
                    <tr>
                        <td><?= limpiar($fila["disp_nombre"]) ?></td>
                        <td><?= limpiar($fila["disp_desc"]) ?></td>
                        <?php if (isset($_SESSION["admin"])) {
                            echo "<td>" . limpiar($fila["disp_mac"]) . "</td>";
                            echo "<td>" . limpiar($fila["disp_ip"]) . "</td>";
                        }
                        ?>
                        <td><?= limpiar($estado) ?></td>
                        <td><?= $diasEspañol ?: "<p>—</p>" ?></td>
                        <td><?= $fila["prog_hora"] ? limpiar($fila["prog_hora"]) : "<p>—</p>" ?></td>
                        <td>
                            <form action="./solicitudes_wol.php" method="post">
                                <input type="hidden" name="mac" value="<?= limpiar($fila["disp_mac"]) ?>">
                                <button type="submit" name="encender">Encender</button>
                            </form>
                        </td>
                        <?php
                        if (isset($_SESSION["admin"])) {
                            echo "<td><a href='editar_equipo.php?id=" . intval(limpiar($fila["disp_id"])) . "'>Editar</a></td>";
                            if ($fila["prog_id"]) {
                                echo "<td><a href='panel_programacion.php?id=" . intval(limpiar($fila["prog_id"])) . "'>Editar Programación</a></td>";
                            } else {
                                echo "<td><a href='panel_programacion.php?disp=" . intval(limpiar($fila["disp_id"])) . "'>Crear Programación</a></td>";
                            }
                        }
                        ?>
                    </tr>
                <?php } ?>
            </tbody>
        </table>

    </main>
</body>

</html>