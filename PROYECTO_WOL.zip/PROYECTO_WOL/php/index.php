<?php
session_start();
require "conexion.php";
require "funciones.inc.php";

if (!isset($_SESSION["intentos"])) {
    $_SESSION["intentos"] = 0;
}

if (isset($_POST["login"]) && $_SERVER["REQUEST_METHOD"] == "POST") {
    $user = limpiar($_REQUEST["username"]);
    $contra = sha1(limpiar($_REQUEST["pass"]));

    $consulta = "SELECT * FROM usuarios WHERE usuario='$user' AND contrasena='$contra'";
    $resultado = $conexion->query($consulta);
    
    if ($resultado->num_rows == 0) {
        $_SESSION["intentos"]++;
        $_SESSION["loginfail"] = "El nombre de usuario o la contraseña no son correctos";
        if ($_SESSION["intentos"] >= 5) {
            error_log("Se ha superado el número de intentos de inicio de sesión.");
            die("Se ha superado el número de intentos de inicio de sesión.");
        }
    } else {
        $_SESSION["intentos"] = 0; 
        $fila = $resultado->fetch_assoc();
        $_SESSION["id"] = limpiar($fila["id"]);
        $_SESSION["name"] = $user;
        $_SESSION["login"] = "estandar";
        error_log("Sesion iniciada como usario estandar. " . $_SESSION["name"]);
        $consulta = "SELECT * FROM usuarios WHERE usuario='$user' AND contrasena='$contra' AND rol='admin'";
        $resultado = $conexion->query($consulta);
        if ($resultado->num_rows > 0) {
            $_SESSION["admin"] = "administrador";
            error_log("Sesion iniciada como usario administrador. " . $_SESSION["name"]);
        }
        header("Location: panel_equipos.php");
        exit();
    }
}

if (isset($_POST["cerrar_sesion"]) && $_SERVER["REQUEST_METHOD"] == "POST") {
    error_log("Sesion cerrada. " . $_SESSION["name"]);
    session_unset();
    session_destroy();
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="David Correa Carmona">
    <link rel="stylesheet" href="./estilos.css">
    <title>Inicio de Sesión</title>
</head>

<body>
    <header>
        <h1>Inicio de sesión</h1>
        <nav class="menu">
            <figure>
                <img src="./img/logo.png" alt="Logo de Nexacom" id="logo" />
            </figure>
        </nav>
    </header>
    <main>
        <?php
        if (isset($_SESSION['loginfail'])) {
            echo "<p>" . $_SESSION["loginfail"] . "</p>";
            unset($_SESSION["loginfail"]);
        }
        ?>
        <form action="./index.php" method="post" class="formulario">
            <input type="text" name="username" placeholder="Nombre de Usuario" required>
            <input type="password" name="pass" placeholder="Contraseña" required>
            <button type="submit" name="login" value="login">Acceder</button>
        </form>
    </main>
</body>

</html>
