#!/bin/bash
nohup php /var/www/html/script_bucle.php > /dev/null 2>&1 &
apache2-foreground
