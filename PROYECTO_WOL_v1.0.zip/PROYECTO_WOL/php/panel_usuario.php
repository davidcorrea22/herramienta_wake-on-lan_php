<?php
session_start();
require "conexion.php";
require "funciones.inc.php";

if (!isset($_SESSION["login"]) || !isset($_SESSION["admin"])) {
    header("Location: index.php");
    exit();
}
$mensaje = "";

?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="David Correa Carmona">
    <link href="./estilos.css" rel="stylesheet" type="text/css">
    <title>Panel de control de usuarios</title>
</head>

<body>
    <header>
        <h1>Panel de control de usuarios</h1>
        <nav class="menu">
            <form action="./panel_equipos.php" method="post"><button type="submit" name="inicio">Volver A Inicio</button></form>
            <form action="./cuenta_usuario.php" method="post"><button type="submit" name="cuenta">Editar Cuenta</button></form>
            <form action="./index.php" method="post"><button type="submit" name="cerrar_sesion">Cerrar Sesión</button></form>
            <form action="./anadir_usuario.php" method="post"><button type="submit" name="usr_anadir">Añadir Usuarios</button></form>
            <form action="./borrar_usuario.php" method="post"><button type="submit" name="usr_borrar">Borrar Usuarios</button></form>
            <form action="./panel_usuario.php" method="post"><button type="submit" name="usuarios">Menú de usuarios</button></form>
        </nav>
    </header>
    <main>
        <p><?= $mensaje ?></p>
        <table>
            <thead>
                <th>NOMBRE DE USUARIO</th>
                <th>ROL</th>
                <th>ESTADO</th>
            </thead>
            <tbody>
                <?php
                $consulta = "SELECT * FROM usuarios";
                $res = $conexion->query($consulta);
                while ($fila = $res->fetch_assoc()) {
                ?>
                    <tr>
                        <td><?= limpiar($fila["usuario"]); ?></td>
                        <td><?= limpiar($fila["rol"]); ?></td>
                        <td><a href="editar_usuario.php?id=<?= intval(limpiar($fila['id'])) ?>">Editar</a></td>
                    </tr>
                <?php }
                $conexion->close(); ?>
            </tbody>
        </table>
    </main>
</body>

</html>