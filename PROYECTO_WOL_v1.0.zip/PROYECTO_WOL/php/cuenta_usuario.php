<?php
session_start();
require "conexion.php";
require "funciones.inc.php";

if (!isset($_SESSION["login"])) {
    header("Location: index.php");
    exit();
}

$mensaje = "";
if (isset($_SESSION["id"])) {
    $id = $_SESSION["id"];
    $consulta = "SELECT * FROM usuarios WHERE id = $id";
    $resultado = $conexion->query($consulta);
    if ($resultado->num_rows > 0) {
        $fila = $resultado->fetch_assoc();
        $usr = limpiar($fila["usuario"]);
        $con = limpiar($fila["contrasena"]);
        $rol = limpiar($fila["rol"]);
    } else {
        die("No se ha encontrado ningún usuario con la ID $id.");
    }
} else {
    die("No se ha especificado ninguna ID.");
}

if (isset($_POST["cambiar"]) && $_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST["nombre"]) && !empty($_POST["oldpasswd"])) {
        $nom = limpiar($_POST["nombre"]);
        $ContraAntigua = sha1(limpiar($_POST["oldpasswd"]));
        if (validar_nombre($nom) && $ContraAntigua == $con) {
            $ContraNueva = $ContraAntigua;
            if (!empty($_POST["newpasswd1"]) && !empty($_POST["newpasswd2"])) {
                $newpasswd1 = limpiar($_POST["newpasswd1"]);
                $newpasswd2 = limpiar($_POST["newpasswd2"]);
                if ($newpasswd1 === $newpasswd2) {
                    if (validar_contra($newpasswd1)) {
                        $ContraNueva = sha1($newpasswd1);
                        if ($ContraNueva ===  $con) {
                            $mensaje = "La nueva contraseña no puede ser la misma que la anterior.";
                        }
                    } else {
                        $mensaje = "La nueva contraseña no cumple los requisitos de seguridad.";
                    }
                } else {
                    $mensaje = "Las nuevas contraseñas no coinciden.";
                }
            }
            if (empty($mensaje)) {
                try {
                    $consulta = "UPDATE usuarios SET usuario = ?, contrasena = ?, rol = ? WHERE id = ?";
                    error_log("Intentando editar el usuario: Id=$id, Nombre=$usr, Rol=$rol");
                    $sentencia = $conexion->prepare($consulta);
                    $sentencia->bind_param("sssi", $nom, $ContraNueva, $rol, $id);
                    if ($sentencia->execute()) {
                        $mensaje = "Se ha editado el usuario correctamente.";
                        error_log("Usuario editado: Id=$id, Nombre=$nom, Rol=$rol");
                    } else {
                        $mensaje = "Error al ejecutar la consulta.";
                        error_log("Error ejecutando la consulta:  $conexion->error");
                    }
                    $sentencia->close();
                } catch (Exception $exc) {
                    $mensaje = "Se ha producido un error.";
                }
            }
        } else {
            $mensaje = "El nombre de usuario o la contraseña no son los correctos.";
        }
    } else {
        $mensaje = "Faltan datos obligatorios.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="David Correa Carmona">
    <link href="./estilos.css" rel="stylesheet" type="text/css">
    <title>Modificar Cuenta</title>
</head>

<body>
    <header>
        <h1>Modificar Cuenta</h1>
        <nav class="menu">
            <form action="./panel_equipos.php" method="post"><button type="submit" name="inicio">Volver A Inicio</button></form>
            <form action="./solicitudes_wol.php" method="post"><button type="submit" name="encender_todos">Encender Todos</button></form>
            <form action="./panel_programacion.php" method="post"><button type="submit" name="programar">Programar Encendido</button></form>
            <form action="./cuenta_usuario.php" method="post"><button type="submit" name="cuenta">Editar Cuenta</button></form>
            <form action="./index.php" method="post"><button type="submit" name="cerrar_sesion">Cerrar Sesión</button></form>
            <?php
            if (isset($_SESSION["admin"])) {
                echo "<form action='./anadir_equipo.php' method='post'><button type='submit' name='anadir'>Añadir Equipos</button></form>";
                echo "<form action='./borrar_equipo.php' method='post'><button type='submit' name='borrar'>Borrar Equipos</button></form>";
                echo "<form action='./panel_usuario.php' method='post'><button type='submit' name='usuarios'>Menú De Usuarios</button></form>";
            }
            ?>
        </nav>
    </header>
    <main>
        <p><?= $mensaje . "Sesión iniciada como " . $_SESSION["name"]; ?></p>
        <form action="" method="post" class="formulario">
            <p>* Nombre de usuario. Solo letras y números. Mínimo 3 carácteres, máximo 50: <input type="text" name="nombre" value="<?= $_SESSION["name"]; ?>" pattern="[a-zA-Z0-9_ ]{3,50}"></p>
            <p>* Contraseña Actual. La que uses ahora mismo. Al menos 8 carácteres, un número, una mayúscula, una minúscula y un carácter especial: <input type="password" name="oldpasswd" required></p>
            <p>* Nueva Contraseña. Opcional: <input type="password" name="newpasswd1" pattern="(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[!@#$%^&*]).{8,}"> </p>
            <p>* Repita La Nueva Contraseña: <input type="password" name="newpasswd2" pattern="(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[!@#$%^&*]).{8,}"> </p>
            <p><input type="submit" name="cambiar" value="Editar Cuenta"></p>
        </form>
    </main>
</body>

</html>